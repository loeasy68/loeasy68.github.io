
# The 'simplepat.rb' program.

while line = gets
    puts "Got a blank line."            if line =~ /^$/
    puts "Line has a curly brace."      if line =~ /[}{]/
    puts "Line contains 'program'."     if line =~ /\bprogram\b/
end # of while.