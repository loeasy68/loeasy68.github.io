class Person
    attr_reader :name, :dob, :nationality
    attr_writer :name, :dob, :nationality

    def initialize( name, dob, nationality )
        @name = name
        @dob = dob
        @nationality = nationality
    end # of initialize.

    def to_s
        "#@name born on #@dob (#@nationality)"
    end # of to_s.
end # of Person.

tom   = Person.new( "Thomas",  "26/05/1945", :Irish )
dick  = Person.new( "Richard", "15/02/1980", :English )
harry = Person.new( "Harold",  "02/11/1975", :American )

people = [ tom, dick, harry ]

people.each { |person| puts person.to_s }