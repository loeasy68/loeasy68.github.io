
# The 'grouping.rb' program.

while line = gets
    line =~ /\w+ (\w+) \w+ (\w+)/

    puts "Second word: '#{$1}' on line #{$.}." if defined? $1
    puts "Fourth word: '#{$2}' on line #{$.}." if defined? $2
end # of while.