
#
# == Synopsis
# A small ruby program which shows the user where a regex matches.
#
# == Usage 
# There are two command-line arguments: 
# 	"target": the string to match against.
# 	"regex": the pattern/regular-expression.
#
# == Author
# Paul Barry, The Institute of Technology, Carlow, Ireland.
# 
# == Copyright
# Copyright (c) 2006, Paul Barry.
# Licensed under GPL v2 .
# 

def show_regexp( target, regex )
#
# Based on the code from page 69, Programming Ruby, 2nd Edition by Dave Thomas.
# 
    if target =~ regex
        # Highlight with chevrons where the successful match occurs.
        "#{$`}>>#{$&}<<#{$'}"
    else
        "no match found"
    end # of if.
end # of show_regexp.

target, regex = ARGV.collect { |arg| arg }  # Doing things the Ruby way ... 
regex = Regexp.new( regex )                 # Convert to regex.
puts show_regexp( target, regex )           # Show the results.